# SCS-Website
SCS Website
Latest version of SCS Concordia's website.

Built using Bootstrap.

#### Color Scheme
Primary: #8464CC
Secondary: #A78AE1
